package sample;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Main")

public class Main extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException{
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");	
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/arya", "root","root");
		String q="insert into user (name,password,phone,email) values(?,?,?,?);";
		PreparedStatement ps=c.prepareStatement(q);
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		String phn=req.getParameter("phn");
		String mail=req.getParameter("mail");
		ps.setString(1, name);
		ps.setString(2,password );
		ps.setString(3, phn);
		ps.setString(4, mail);
		
		PrintWriter out=res.getWriter();
		int r=ps.executeUpdate();
		res.setContentType("text/html");
		out.print("<h3>Registration Sucessfully!<h3>");
			
		}catch(SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}