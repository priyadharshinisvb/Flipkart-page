package jdbc;
import java.sql.*;

public class Main {
	public static void main(String[] args) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/arya";
		String name="root";
		String pass="root";
		Connection c = DriverManager.getConnection(url,name,pass);
		String q = "Select * from detailsofarya";
		Statement st = c.createStatement();
		ResultSet rs = st.executeQuery(q);
		
		while(rs.next()) {
			int id = rs.getInt(1);
			String firstname = rs.getString(2);
			String secondname = rs.getString(3);
			System.out.println( id+" "+firstname+" "+secondname);
		}
		
	
	}

}
