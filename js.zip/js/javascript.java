function validate(event) {
    event.preventDefault();

    document.getElementById("errorphn").innerText = "";
    document.getElementById("erroremail").innerText = "";
    document.getElementById("errorpass").innerText = "";

    let name = document.getElementById("name").value.trim();
    let mob = document.getElementById("mob").value.trim();
    let email = document.getElementById("email").value.trim();
    let pass = document.getElementById("pass").value.trim();

    if (name === "") {
        alert("Enter your name");
        return;
    }

    if (!/^\d{10}$/.test(mob)) {
        document.getElementById("errorphn").innerText = "Enter 10 digit number";
        return;
    }

    if (!email.endsWith("@gmail.com")) {
        document.getElementById("erroremail").innerText = "Use Gmail only";
        return;
    }

    if (pass.length < 6) {
        document.getElementById("errorpass").innerText =
            "Minimum 6 characters required";
        return;
    }

    alert("Login Successful ✅");
    window.location.reload();
}